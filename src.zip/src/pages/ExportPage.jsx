export default function ExportPage() {
  return (
    <main className='page'>
      <h2>Export</h2>
      <p>Export preview goes here.</p>
    </main>
  );
}
