import { useNavigate } from 'react-router-dom';
import { useFormStore } from '../store/useFormStore';
import { fieldsForPage, FIELD_BY_ID } from '../config/fields';
import { LANGUAGE_LABEL_BY_CODE } from '../config/languageOptions';

export default function MainPage() {
  const setValue = useFormStore((s) => s.setValue);
  const values = useFormStore((s) => s.values);
  const errors = useFormStore((s) => s.errors);
  const hints = useFormStore((s) => s.hints);

  const fields = fieldsForPage(1);

  return (
    <div className='page-layout'>
      {/* Top info box */}
      <div className='page info'>
        <h2>Statement of Work Generator for GNP</h2>
        <p>
          Enter the required information in the left panel. Then review the
          fields in the right panel.
        </p>
      </div>

      {/* Left / Right panels */}
      <div className='page left'>
        <h2>Page 1: Enter Required Information</h2>
        <form className='form-grid'>
          <div className='hdr label'>Field</div>
          <div className='hdr input'>Input</div>
          <div className='hdr echo'>Current value</div>

          {page1Fields.map((field) => (
            <FieldRow
              key={field.id}
              field={field}
              value={values[field.id]}
              error={errors[field.id]}
              hint={hints[field.id]}
              onChange={(val) => setValue(field.id, val)}
            />
          ))}
        </form>
      </div>
      <div className='page right'>
        <h2>Statement of Work</h2>
      </div>

      {/* Bottom buttons */}
      <div className='buttons'>
        <button className='btn primary' onClick={() => navigate('/export')}>
          Continue
        </button>
        <button className='btn danger' onClick={resetAll}>
          Clear
        </button>
      </div>
    </div>
  );
}
